Hi :D first, I'd say a big thanks to you, that you've downloaded my skin! :) People like you make me very happy! :P

Ok, here I'll explain, how to insert the skin, it's very easy.

You copy the "cstrike" folder and paste it in the following address (where you're counter-strike source is stored).


I've stored it in:

-------------------------------------------------------------------------------------------------------------------------------

#### C:\program files\Steam\SteamApps\maikv1993(here your account name!)\counter-strike source ####


When you're in the last folder, where the .vtf is stored, it have to look like this:


#### C:\program files\Steam\SteamApps\maikv1993(here your account name!)\counter-strike source\cstrike\materials\models\weapons\v_models\hands ####


-------------------------------------------------------------------------------------------------------------------------------

Please remember, most of the online servers doesn't accept edited skins (settings off), there you'll play with the normal skins.
But we love to create some new skins :D 


If you violate my copyright, it will have consequences!
And now, have fun with the new skin! :)

Best regards,
coRreXx





If you want, you can add me in steam^^ (name in link)

